# 🐵 ROOFING MONKEYS BOT v2 — Guía de instalación

## Qué hace el bot
- Lee mensajes de texto e imágenes de tus grupos de WhatsApp
- Claude analiza el contenido (texto + fotos juntos)
- Crea automáticamente el registro en Notion con:
  - Todos los campos estructurados (dirección, equipo, status, etc.)
  - Las fotos adjuntas visibles dentro de la página de Notion

---

## Variables que necesitas recopilar primero

| Variable | Dónde obtenerla |
|----------|----------------|
| `ANTHROPIC_API_KEY` | console.anthropic.com → API Keys |
| `TWILIO_ACCOUNT_SID` | console.twilio.com → panel principal (Account Info) |
| `TWILIO_AUTH_TOKEN` | console.twilio.com → panel principal (Account Info) |
| `NOTION_TOKEN` | notion.so/my-integrations → tu integración |
| `NOTION_DB_OP` | URL de la base OP en Notion |
| `NOTION_DB_COBRANZA` | URL de la base Cobranza en Notion |

---

## PASO 1 — Crear cuenta en GitHub (5 min, gratis)

1. Ve a https://github.com → Sign up
2. Crea tu cuenta y verifica el email

---

## PASO 2 — Subir el código (10 min)

1. En GitHub → botón verde **New**
2. Nombre: `roofing-monkeys-bot` → **Private** → Create repository
3. Sube estos 4 archivos (arrastra o usa GitHub Desktop):
   - `index.js`
   - `package.json`
   - `Procfile`
   - `.gitignore`
4. **NO subas `.env`** — tiene tus claves secretas

---

## PASO 3 — Integración de Notion (5 min, gratis)

1. Ve a https://www.notion.so/my-integrations
2. **+ New integration** → Nombre: `Roofing Monkeys Bot` → Submit
3. Copia el **Internal Integration Secret** → es tu `NOTION_TOKEN`

4. **Conectar la integración a tus bases:**
   - Abre la base **🔧 OP** en Notion
   - Clic en `...` (arriba derecha) → **Connections** → busca `Roofing Monkeys Bot` → conectar
   - Repite para **🚨 Cobranza**

5. **Copiar los IDs de las bases:**
   - URL ejemplo: `https://notion.so/workspace/abc123def456ghij?v=xyz`
   - El ID es `abc123def456ghij` (entre la última `/` y el `?v=`)

---

## PASO 4 — Deploy en Railway (10 min, ~$5/mes)

1. Ve a https://railway.app → Start a New Project
2. **Deploy from GitHub repo** → conecta GitHub → selecciona `roofing-monkeys-bot`
3. Ve a la pestaña **Variables** y agrega:

| Variable | Tu valor |
|----------|----------|
| `ANTHROPIC_API_KEY` | `sk-ant-...` |
| `TWILIO_ACCOUNT_SID` | `ACxxx...` |
| `TWILIO_AUTH_TOKEN` | `xxx...` |
| `NOTION_TOKEN` | `secret_...` |
| `NOTION_DB_OP` | ID de la base OP |
| `NOTION_DB_COBRANZA` | ID de la base Cobranza |

4. Clic en **Deploy**
5. Railway te da una URL pública:
   `https://roofing-monkeys-bot-production.up.railway.app`
   → **Copia esta URL**

---

## PASO 5 — Configurar Twilio Webhook (3 min)

1. Ve a https://console.twilio.com
2. **Messaging → Try it out → Send a WhatsApp message**
3. Clic en **Sandbox Settings**
4. En **"When a message comes in"** pega:
   ```
   https://TU-URL.up.railway.app/webhook
   ```
5. Método: `HTTP POST` → **Save**

---

## PASO 6 — Conectar miembros del grupo (2 min por persona)

Cada miembro del grupo que quiera que el bot procese sus mensajes debe:
1. Abrir WhatsApp
2. Enviar al número `+1 415 523 8886`:
   ```
   join [tu-código-sandbox]
   ```
   (El código sandbox está en la pantalla de Twilio Sandbox)

---

## PASO 7 — Probar

Manda este mensaje al número de Twilio desde WhatsApp:

```
149 Hollywood Ave, North York
Le hicieron falta 15 bundles al equipo de Matias
También hay una fuga en el techo plano
```

Y adjunta una foto cualquiera.

En segundos deberías ver en Notion:
- ✅ Registro nuevo en la base OP
- 📸 La foto visible dentro de la página

---

## Cómo funciona la integración de imágenes

```
WhatsApp → Twilio
          ↓
          Webhook recibe: texto + URLs de imágenes
          ↓
          Se descargan las imágenes (con autenticación Twilio)
          ↓
          Claude analiza texto + imágenes juntos
          ↓
          Se crea la página en Notion con los campos
          ↓
          Se adjuntan las fotos como bloques en el body de la página
```

> **Nota:** Las URLs de Twilio expiran en ~1 hora. Las fotos quedan
> embebidas en Notion antes de que expiren. Si Railway tarda más de
> 1 hora en procesar (muy raro), la foto no aparecerá.

---

## Agregar un grupo nuevo en el futuro

1. Crea la base de datos en Notion (puedo hacerlo yo)
2. En Railway → Variables → agrega `NOTION_DB_NUEVABASE=tu-id`
3. Edita `index.js` en 3 lugares:

```javascript
// 1. En NOTION_DBS:
nuevabase: process.env.NOTION_DB_NUEVABASE,

// 2. En detectarGrupo():
if (texto.includes("ventas")) return "nuevabase";

// 3. En PROMPTS, agrega el prompt para el nuevo grupo

// 4. En crearEnNotion(), agrega el bloque if (grupo === "nuevabase")
```

---

## Costo mensual estimado

| Servicio | Costo |
|----------|-------|
| Railway | ~$5 USD |
| Claude API (500 msgs/mes con fotos) | ~$5 USD |
| Twilio sandbox | Gratis |
| Notion | Gratis |
| **Total** | **~$10 USD/mes** |

---

## Ver logs si algo falla

Railway → tu proyecto → **Deployments** → último deploy → **View Logs**

Busca líneas con `❌` para ver el error exacto.
